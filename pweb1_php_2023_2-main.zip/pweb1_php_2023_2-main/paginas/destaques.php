<?php

include "./cabecalho.inc.php";
include "./menu.inc.php";

?>

<div>
    <h3>Destaques</h3>
    <div>
        <p>Teste teste teste teste</p>
        <p>Data: <?php echo date("d/m/Y")  ?></p>
    </div>
</div>   

<?php
include "./rodape.inc.php";
?>