<footer>
<p>Todos os direitos reservados.</p>
</footer>
</body>
</html>